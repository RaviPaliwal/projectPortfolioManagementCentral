import React, { useMemo } from 'react'
import {
  Box,
  Typography,
  Paper,
  Grid,
  LinearProgress,
  Chip,
  useTheme,
  Tooltip,
} from '@mui/material'
import FlagIcon from '@mui/icons-material/Flag'
import AssignmentIcon from '@mui/icons-material/Assignment'
import BugReportIcon from '@mui/icons-material/BugReport'
import WarningAmberIcon from '@mui/icons-material/WarningAmber'
import HowToRegIcon from '@mui/icons-material/HowToReg'
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet'
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents'
import GroupIcon from '@mui/icons-material/Group'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import ErrorIcon from '@mui/icons-material/Error'
import CalendarTodayIcon from '@mui/icons-material/CalendarToday'
import TrendingUpIcon from '@mui/icons-material/TrendingUp'
import LightbulbIcon from '@mui/icons-material/Lightbulb'

import type { ProjectModel, ProjectMilestoneModel, ProjectTaskModel, RiskModel, IssueModel, BudgetLineModel, GateReviewModel, BenefitModel, AgentInsightModel } from '@/types/dataverse'
import { StatusChip, StatusTag } from '@/components/common'
import { currency } from '../../constants'
import { fontSizes } from '@/styles'

interface ProjectOverviewTabProps {
  project: ProjectModel
  milestones?: ProjectMilestoneModel[]
  tasks?: ProjectTaskModel[]
  risks?: RiskModel[]
  issues?: IssueModel[]
  budgetLines?: BudgetLineModel[]
  gateReviews?: GateReviewModel[]
  benefits?: BenefitModel[]
  resources?: any[]
  insights?: AgentInsightModel[]
}

// ─── Gate Labels ───────────────────────────────────────────────────
const GATE_STAGE_LABELS: Record<string, string> = {
  '0': 'Gate 1', '1': 'Gate 2', '2': 'Gate 3', '3': 'Gate 4',
}
const OUTCOME_LABELS: Record<string, string> = {
  '0': 'Approved', '1': 'Conditional', '2': 'Not Yet Reviewed', '3': 'In Progress', '4': 'Rejected',
}
const OUTCOME_COLORS: Record<string, 'success' | 'warning' | 'default' | 'info' | 'error'> = {
  '0': 'success', '1': 'warning', '2': 'default', '3': 'info', '4': 'error',
}

// ─── StatCard (Equal Heights) ──────────────────────────────────────
const StatCard: React.FC<{
  label: string
  value: string | number
  icon: React.ReactNode
  color: string
  subtitle?: string
  valueColor?: string
}> = ({ label, value, icon, color, subtitle, valueColor }) => (
  <Paper
    variant="outlined"
    sx={{
      p: 2,
      borderRadius: 1.5,
      borderLeft: `3px solid ${color}`,
      transition: 'all 0.2s ease',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      '&:hover': { transform: 'translateY(-2px)', boxShadow: 1 },
    }}
  >
    <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <Box>
        <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, fontSize: fontSizes.xs }}>
          {label}
        </Typography>
        <Typography variant="h5" sx={{ fontWeight: 700, mt: 0.25, color: valueColor ?? 'text.primary' }}>
          {value}
        </Typography>
        {subtitle && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.25 }}>
            {subtitle}
          </Typography>
        )}
      </Box>
      <Box sx={{ color, opacity: 0.7, flexShrink: 0 }}>{icon}</Box>
    </Box>
  </Paper>
)

// ─── Quick Action Row ──────────────────────────────────────────────
interface ActionItem {
  id: string
  type: 'risk' | 'issue' | 'overdue_milestone' | 'pending_gate' | 'overdue_task'
  title: string
  description: string
  severity: 'high' | 'medium' | 'low'
  date?: string
}

const QuickActionRow: React.FC<{ item: ActionItem }> = ({ item }) => {
  const theme = useTheme()
  const severityColor = item.severity === 'high' ? 'error.main' : item.severity === 'medium' ? 'warning.main' : 'info.main'
  const typeIcons: Record<string, React.ReactNode> = {
    risk: <BugReportIcon sx={{ fontSize: 16, color: severityColor }} />,
    issue: <WarningAmberIcon sx={{ fontSize: 16, color: severityColor }} />,
    overdue_milestone: <FlagIcon sx={{ fontSize: 16, color: severityColor }} />,
    pending_gate: <HowToRegIcon sx={{ fontSize: 16, color: severityColor }} />,
    overdue_task: <AssignmentIcon sx={{ fontSize: 16, color: severityColor }} />,
  }

  return (
    <Box
      sx={{
        display: 'flex', alignItems: 'center', gap: 1.25, p: 1.15,
        borderRadius: 1.15,
        bgcolor: theme.palette.action.hover,
        borderLeft: `3px solid ${severityColor}`,
        transition: 'background-color 0.15s',
        cursor: 'default',
        '&:hover': { bgcolor: theme.palette.action.selected },
      }}
    >
      {typeIcons[item.type]}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography variant="body2" sx={{ fontWeight: 600, lineHeight: 1.25, fontSize: fontSizes.smMd }}>
          {item.title}
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.2, mt: 0.15, fontSize: fontSizes.xs }}>
          {item.description}{item.date ? ` · ${new Date(item.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}` : ''}
        </Typography>
      </Box>
      <Chip
        label={item.severity.toUpperCase()}
        size="small"
        color={item.severity === 'high' ? 'error' : item.severity === 'medium' ? 'warning' : 'info'}
        variant="outlined"
        sx={{ fontWeight: 700, fontSize: 8, height: 20, flexShrink: 0 }}
      />
    </Box>
  )
}

// ─── Milestone Timeline Item ───────────────────────────────────────
const MilestoneItem: React.FC<{ milestone: ProjectMilestoneModel }> = ({ milestone }) => {
  const isOverdue = milestone.pm_planneddate && new Date(milestone.pm_planneddate) < new Date() && milestone.pm_status !== '0'
  const isCompleted = milestone.pm_status === '0' || milestone.pm_ragstatus === '1'

  return (
    <Box sx={{ display: 'flex', gap: 1.5, position: 'relative' }}>
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 20, flexShrink: 0 }}>
        <Box
          sx={{
            width: 14, height: 14, borderRadius: '50%',
            bgcolor: isCompleted ? 'success.main' : isOverdue ? 'error.main' : 'primary.main',
            border: '2px solid',
            borderColor: isCompleted ? 'success.light' : isOverdue ? 'error.light' : 'primary.light',
            boxSizing: 'border-box',
            flexShrink: 0,
            zIndex: 1,
          }}
        />
      </Box>
      <Box sx={{ flex: 1, pb: 1.5 }}>
        <Typography variant="body2" sx={{ fontWeight: 600, lineHeight: 1.3 }}>{milestone.pm_milestonename}</Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.25, flexWrap: 'wrap' }}>
          <Typography variant="caption" color="text.secondary">
            {milestone.pm_planneddate ? new Date(milestone.pm_planneddate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'TBD'}
          </Typography>
          {milestone.pm_ragstatus && <StatusChip status={milestone.pm_ragstatus} type="rag" size="small" />}
          {milestone.pm_actualdate && (
            <Typography variant="caption" color="success.main" sx={{ fontWeight: 600 }}>
              ✓ {new Date(milestone.pm_actualdate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
            </Typography>
          )}
          {isOverdue && <Typography variant="caption" color="error.main" sx={{ fontWeight: 700 }}>OVERDUE</Typography>}
        </Box>
      </Box>
    </Box>
  )
}

// ─── Main Component ────────────────────────────────────────────────
export const ProjectOverviewTab: React.FC<ProjectOverviewTabProps> = ({
  project,
  milestones = [],
  tasks = [],
  risks = [],
  issues = [],
  budgetLines = [],
  gateReviews = [],
  benefits = [],
  resources = [],
  insights = [],
}) => {
  const theme = useTheme()

  // ── Compute Metrics ──────────────────────────────────────────────
  const metrics = useMemo(() => {
    const totalBudget = budgetLines.reduce((s, b) => s + (b.pm_approvedbudgeteur ?? 0), 0)
    const totalSpent = budgetLines.reduce((s, b) => s + (b.pm_actualspendeur ?? 0), 0)
    const completedTasks = tasks.filter(t => (t.pm_percentcomplete ?? 0) >= 100).length
    const inProgressTasks = tasks.filter(t => (t.pm_percentcomplete ?? 0) > 0 && (t.pm_percentcomplete ?? 0) < 100).length
    const escalatedRisks = risks.filter(r => r.pm_ragstatus === '2' || r.pm_ragstatus === 2).length
    const openRisks = risks.filter(r => r.pm_ragstatus !== '1').length
    const openIssues = issues.filter((i: any) => i.pm_issuestatus !== '1' && i.pm_issuestatus !== 1).length
    const highPriorityIssues = issues.filter((i: any) => i.pm_prioritylevel === '1' || i.pm_prioritylevel === 1).length
    const overdueMilestones = milestones.filter(m => m.pm_planneddate && new Date(m.pm_planneddate) < new Date() && m.pm_status !== '0' && m.pm_status !== 0).length
    const pendingGates = gateReviews.filter(g => String(g.pm_reviewstatus) === '1').length
    const completedMilestones = milestones.filter(m => m.pm_status === '0' || m.pm_status === 0 || m.pm_ragstatus === '1').length
    const achievedBenefits = benefits.filter(b => String(b.pm_benefitstatus) === '2' || b.pm_benefitstatus === 2).length
    const totalAllocatedHours = resources.reduce((s: number, r: any) => s + (r.pm_allocatedhours ?? 0), 0)
    const overallProgress = tasks.length > 0
      ? Math.round(tasks.reduce((s, t) => s + (t.pm_percentcomplete ?? 0), 0) / tasks.length)
      : (project.pm_percentcomplete ?? 0)

    return {
      totalBudget, totalSpent, completedTasks, inProgressTasks,
      escalatedRisks, openRisks, openIssues, highPriorityIssues,
      overdueMilestones, pendingGates, completedMilestones,
      achievedBenefits, totalAllocatedHours, overallProgress,
    }
  }, [project, milestones, tasks, risks, issues, budgetLines, gateReviews, benefits, resources])

  // ── Quick Actions Items ──────────────────────────────────────────
  const actionItems = useMemo((): ActionItem[] => {
    const items: ActionItem[] = []

    risks.filter(r => r.pm_ragstatus === '2' || r.pm_ragstatus === 2).slice(0, 2).forEach(r => {
      items.push({
        id: `risk-${r.pm_riskid}`, type: 'risk',
        title: r.pm_risktitle ?? 'Untitled Risk',
        description: `Critical — ${r.pm_riskowner ?? 'Unassigned'}`,
        severity: 'high', date: r.pm_targetclosedate,
      })
    })

    issues.filter((i: any) => (i.pm_prioritylevel === '1' || i.pm_prioritylevel === 1) && (i.pm_issuestatus !== '1' && i.pm_issuestatus !== 1)).slice(0, 2).forEach(i => {
      items.push({
        id: `issue-${(i as any).pm_issueid}`, type: 'issue',
        title: (i as any).pm_issuetitle ?? 'Untitled Issue',
        description: `High priority — ${(i as any).pm_issueowner ?? 'Unassigned'}`,
        severity: 'high', date: (i as any).pm_targetresolutiondate,
      })
    })

    return items
  }, [risks, issues])

  // ── Upcoming milestones ──────────────────────────────────────────
  const upcomingMilestones = useMemo(() => {
    return [...milestones]
      .filter(m => m.pm_status !== '0' && m.pm_status !== 0 && m.pm_ragstatus !== '1')
      .sort((a, b) => {
        const dateA = a.pm_planneddate ? new Date(a.pm_planneddate).getTime() : 0
        const dateB = b.pm_planneddate ? new Date(b.pm_planneddate).getTime() : 0
        return dateA - dateB
      })
      .slice(0, 4)
  }, [milestones])

  // ── Recent gate reviews ──────────────────────────────────────────
  const recentGates = useMemo(() => {
    return [...gateReviews].sort((a, b) => {
      const dateA = a.pm_actualreviewdate ? new Date(a.pm_actualreviewdate).getTime() : a.pm_plannedreviewdate ? new Date(a.pm_plannedreviewdate).getTime() : 0
      const dateB = b.pm_actualreviewdate ? new Date(b.pm_actualreviewdate).getTime() : b.pm_plannedreviewdate ? new Date(b.pm_plannedreviewdate).getTime() : 0
      return dateB - dateA
    }).slice(0, 3)
  }, [gateReviews])

  const budgetUtilPct = metrics.totalBudget > 0 ? Math.round((metrics.totalSpent / metrics.totalBudget) * 100) : 0
  // ── Agent Insights ────────────────────────────────────────────
  const alertInsights = insights.filter(i => String(i.pm_insighttype) === '125570000')
  const suggestionInsights = insights.filter(i => String(i.pm_insighttype) === '125570001')
  const unreviewedInsights = insights.filter(i => String(i.pm_actionstatus) === '125570000')
  const hasActionItems = actionItems.length > 0

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, mt: 1 }}>
      {/* ━━ Row 1: Quick Identity Cards ━━ */}
      <Grid container spacing={1.5}>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>RAG</Typography>
            <Box sx={{ mt: 0.5 }}><StatusChip status={project.pm_ragstatus} type="rag" size="medium" /></Box>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>Phase</Typography>
            <Box sx={{ mt: 0.5 }}><StatusTag label={['Execution','Planning','Closure'][Number(project.pm_projectphase)] || 'Unknown'} color={(['success','info','secondary'][Number(project.pm_projectphase)] || 'default') as any} size="small" /></Box>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>Manager</Typography>
            <Typography variant="body2" sx={{ fontWeight: 600, mt: 0.5, fontSize: fontSizes.smMd }}>{project.pm_projectmanagername || '—'}</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>Sponsor</Typography>
            <Typography variant="body2" sx={{ fontWeight: 600, mt: 0.5, fontSize: fontSizes.smMd }}>{project.pm_projectsponsor || '—'}</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>Portfolio</Typography>
            <Typography variant="body2" noWrap sx={{ fontWeight: 600, mt: 0.5, fontSize: fontSizes.smMd, maxWidth: 130 }}>{project.pm_portfolioname || '—'}</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, sm: 3, md: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 1.5, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: 9, letterSpacing: 0.5 }}>Programme</Typography>
            <Typography variant="body2" noWrap sx={{ fontWeight: 600, mt: 0.5, fontSize: fontSizes.smMd, maxWidth: 130 }}>{project.pm_programmename || '—'}</Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* ━━ Row 2: KPI Stat Cards ━━ */}
      <Grid container spacing={1.5}>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Progress" value={`${metrics.overallProgress}%`} icon={<TrendingUpIcon />} color="#3b82f6" />
        </Grid>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Tasks" value={`${metrics.completedTasks}/${tasks.length}`} icon={<AssignmentIcon />} color="#8b5cf6" subtitle={`${metrics.inProgressTasks} in progress`} />
        </Grid>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Milestones" value={`${metrics.completedMilestones}/${milestones.length}`} icon={<FlagIcon />} color="#f59e0b" subtitle={`${metrics.overdueMilestones} overdue`} valueColor={metrics.overdueMilestones > 0 ? 'error.main' : undefined} />
        </Grid>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Risks" value={risks.length} icon={<BugReportIcon />} color={metrics.escalatedRisks > 0 ? '#ef4444' : '#22c55e'} subtitle={`${metrics.escalatedRisks} critical`} valueColor={metrics.escalatedRisks > 0 ? 'error.main' : undefined} />
        </Grid>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Issues" value={issues.length} icon={<WarningAmberIcon />} color={metrics.highPriorityIssues > 0 ? '#f59e0b' : '#22c55e'} subtitle={`${metrics.highPriorityIssues} high priority`} />
        </Grid>
        <Grid size={{ xs: 6, sm: 4, md: 2 }}>
          <StatCard label="Budget" value={currency(metrics.totalBudget)} icon={<AccountBalanceWalletIcon />} color="#22c55e" subtitle={`${budgetUtilPct}% utilized`} />
        </Grid>
      </Grid>

      {/* ━━ Row 3: Progress Bar ━━ */}
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1, flexWrap: 'wrap', gap: 1 }}>
          <Typography variant="body2" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 0.75 }}>
            <TrendingUpIcon sx={{ fontSize: 18, color: 'primary.main' }} /> Overall Project Progress
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            {project.pm_plannedstartdate && (
              <Typography variant="caption" color="text.secondary">
                Start: {new Date(project.pm_plannedstartdate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
              </Typography>
            )}
            {project.pm_plannedenddate && (
              <Typography variant="caption" color="text.secondary">
                Target: {new Date(project.pm_plannedenddate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
              </Typography>
            )}
            <Typography variant="body2" sx={{ fontWeight: 800, color: metrics.overallProgress >= 100 ? 'success.main' : 'primary.main' }}>
              {metrics.overallProgress}%
            </Typography>
          </Box>
        </Box>
        <LinearProgress
          variant="determinate"
          value={metrics.overallProgress}
          sx={{
            height: 12, borderRadius: 2,
            bgcolor: theme.palette.action.hover,
            '& .MuiLinearProgress-bar': {
              borderRadius: 2,
              bgcolor: metrics.overallProgress >= 100 ? 'success.main' : metrics.overallProgress >= 50 ? '#3b82f6' : 'warning.main',
            },
          }}
        />
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 0.75 }}>
          <Typography variant="caption" color="text.secondary">{tasks.length} total tasks</Typography>
          <Typography variant="caption" color="text.secondary">{metrics.completedTasks} completed · {metrics.inProgressTasks} in progress · {tasks.length - metrics.completedTasks - metrics.inProgressTasks} not started</Typography>
        </Box>
      </Paper>

      {/* ━━ Row 4: Quick Actions Section ━━ */}
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 0.75 }}>
            <ErrorIcon sx={{ fontSize: 18, color: hasActionItems ? 'error.main' : 'success.main' }} />
            Quick Actions
          </Typography>
          <StatusTag
            label={hasActionItems ? `${actionItems.length} items` : 'All Clear'}
            size="small"
            color={hasActionItems ? 'warning' : 'success'}
            variant="outlined"
          />
        </Box>

        <Grid container spacing={1.5} alignItems="stretch">
          {/* Action items column */}
          <Grid size={{ xs: 12, md: hasActionItems ? 7 : 12 }}>
            {hasActionItems ? (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                {actionItems.map((item) => (
                  <QuickActionRow key={item.id} item={item} />
                ))}
              </Box>
            ) : (
              <Box sx={{ textAlign: 'center', py: 2 }}>
                <CheckCircleIcon sx={{ fontSize: 32, color: 'success.main', mb: 0.5 }} />
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 600 }}>
                  All clear — no pending actions
                </Typography>
              </Box>
            )}
          </Grid>

          {/* Shortcut chips column */}
          {hasActionItems && (
            <Grid size={{ xs: 12, md: 5 }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75, justifyContent: 'center', height: '100%' }}>
                <Tooltip title={risks.length > 0 ? `${risks.length} risks logged` : 'No risks logged'}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, py: 0.75, borderRadius: 1, '&:hover': { bgcolor: 'action.hover' }, cursor: 'default' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <BugReportIcon sx={{ fontSize: 16, color: metrics.escalatedRisks > 0 ? 'error.main' : 'text.secondary' }} />
                      <Typography variant="caption" sx={{ fontWeight: 500 }}>Open Risks</Typography>
                    </Box>
                    <Chip label={risks.length} size="small" color={metrics.escalatedRisks > 0 ? 'error' : 'default'} variant="outlined" sx={{ fontWeight: 700, fontSize: 10, height: 20 }} />
                  </Box>
                </Tooltip>
                <Tooltip title={issues.length > 0 ? `${issues.length} issues logged` : 'No issues logged'}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, py: 0.75, borderRadius: 1, '&:hover': { bgcolor: 'action.hover' }, cursor: 'default' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <WarningAmberIcon sx={{ fontSize: 16, color: metrics.highPriorityIssues > 0 ? 'warning.main' : 'text.secondary' }} />
                      <Typography variant="caption" sx={{ fontWeight: 500 }}>Open Issues</Typography>
                    </Box>
                    <Chip label={issues.length} size="small" color={metrics.highPriorityIssues > 0 ? 'warning' : 'default'} variant="outlined" sx={{ fontWeight: 700, fontSize: 10, height: 20 }} />
                  </Box>
                </Tooltip>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, py: 0.75, borderRadius: 1, '&:hover': { bgcolor: 'action.hover' }, cursor: 'default' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <FlagIcon sx={{ fontSize: 16, color: metrics.overdueMilestones > 0 ? 'error.main' : 'text.secondary' }} />
                    <Typography variant="caption" sx={{ fontWeight: 500 }}>Overdue Milestones</Typography>
                  </Box>
                  <Chip label={metrics.overdueMilestones} size="small" color={metrics.overdueMilestones > 0 ? 'error' : 'default'} variant="outlined" sx={{ fontWeight: 700, fontSize: 10, height: 20 }} />
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.5, py: 0.75, borderRadius: 1, '&:hover': { bgcolor: 'action.hover' }, cursor: 'default' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <HowToRegIcon sx={{ fontSize: 16, color: metrics.pendingGates > 0 ? 'warning.main' : 'text.secondary' }} />
                    <Typography variant="caption" sx={{ fontWeight: 500 }}>Pending Gates</Typography>
                  </Box>
                  <Chip label={metrics.pendingGates} size="small" color={metrics.pendingGates > 0 ? 'warning' : 'default'} variant="outlined" sx={{ fontWeight: 700, fontSize: 10, height: 20 }} />
                </Box>
              </Box>
            </Grid>
          )}
        </Grid>
      </Paper>

      {/* ━━ Row 4b: Agent Insights ━━ */}
      {insights.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <LightbulbIcon sx={{ fontSize: 18, color: 'info.main' }} />
              AI Agent Insights
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <StatusTag label={`${alertInsights.length} alerts`} size="small" color={alertInsights.length > 0 ? 'error' : 'success'} variant="outlined" />
              <StatusTag label={`${suggestionInsights.length} suggestions`} size="small" color={suggestionInsights.length > 0 ? 'info' : 'default'} variant="outlined" />
              {unreviewedInsights.length > 0 && (
                <StatusTag label={`${unreviewedInsights.length} unreviewed`} size="small" color="warning" variant="outlined" />
              )}
            </Box>
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {insights.slice(0, 4).map((insight) => {
              const isAlert = String(insight.pm_insighttype) === '125570000'
              const isUnreviewed = String(insight.pm_actionstatus) === '125570000'
              const priorityColor = String(insight.pm_priority) === '2' ? 'error.main'
                : String(insight.pm_priority) === '1' ? 'warning.main'
                : 'info.main'

              return (
                <Box
                  key={insight.pm_agentinsightid}
                  sx={{
                    display: 'flex', alignItems: 'flex-start', gap: 1.5, p: 1.25,
                    borderRadius: 1.15,
                    bgcolor: isAlert ? 'rgba(239, 68, 68, 0.05)' : 'rgba(59, 130, 246, 0.05)',
                    borderLeft: `3px solid ${isAlert ? 'error.main' : 'info.main'}`,
                    transition: 'background-color 0.15s',
                    '&:hover': { bgcolor: isAlert ? 'rgba(239, 68, 68, 0.1)' : 'rgba(59, 130, 246, 0.1)' },
                  }}
                >
                  <Box sx={{ color: isAlert ? 'error.main' : 'info.main', mt: 0.25, flexShrink: 0 }}>
                    {isAlert ? <ErrorIcon sx={{ fontSize: 18 }} /> : <LightbulbIcon sx={{ fontSize: 18 }} />}
                  </Box>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                      <Typography variant="body2" sx={{ fontWeight: 700 }}>
                        {insight.pm_insighttitle ?? (isAlert ? 'Alert' : 'Suggestion')}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 0.5 }}>
                        {isUnreviewed && (
                          <Typography variant="caption" sx={{ color: 'warning.main', fontWeight: 700, fontSize: 9 }}>NEW</Typography>
                        )}
                        {insight.pm_confidencescore && (
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: 9 }}>
                            {Math.round(insight.pm_confidencescore * 100)}% confidence
                          </Typography>
                        )}
                      </Box>
                    </Box>
                    {insight.pm_insightdescription && (
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', lineHeight: 1.35, mt: 0.15 }}>
                        {insight.pm_insightdescription}
                      </Typography>
                    )}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5, flexWrap: 'wrap' }}>
                      {insight.pm_sourceagent && (
                        <Typography variant="caption" sx={{ fontSize: 9, color: 'text.disabled' }}>
                          Source: {insight.pm_sourceagent}
                        </Typography>
                      )}
                      {insight.createdon && (
                        <Typography variant="caption" sx={{ fontSize: 9, color: 'text.disabled' }}>
                          {new Date(insight.createdon).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        </Typography>
                      )}
                      {insight.pm_priorityname && (
                        <Chip label={insight.pm_priorityname} size="small" variant="outlined" sx={{ fontWeight: 600, fontSize: 8, height: 18, color: priorityColor }} />
                      )}
                    </Box>
                  </Box>
                </Box>
              )
            })}
          </Box>
        </Paper>
      )}

      {/* ━━ Row 5: Milestones + Gate Reviews ━━ */}
      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 1.5, height: '100%' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <FlagIcon sx={{ fontSize: 18, color: 'warning.main' }} /> Live Milestones
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                {metrics.completedMilestones}/{milestones.length} completed
              </Typography>
            </Box>
            {upcomingMilestones.length > 0 ? (
              <Box>
                {upcomingMilestones.map((ms, idx) => (
                  <React.Fragment key={ms.pm_projectmilestoneid}>
                    <MilestoneItem milestone={ms} />
                    {idx < upcomingMilestones.length - 1 && (
                      <Box sx={{ borderLeft: `2px dashed ${theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`, ml: 0.65, height: 8 }} />
                    )}
                  </React.Fragment>
                ))}
              </Box>
            ) : (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 3 }}>
                {milestones.length === 0 ? 'No milestones defined yet.' : 'All milestones completed.'}
              </Typography>
            )}
          </Paper>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 1.5, height: '100%' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <HowToRegIcon sx={{ fontSize: 18, color: 'primary.main' }} /> Gate Reviews
              </Typography>
              <StatusTag label={`${metrics.pendingGates} pending`} size="small" color={metrics.pendingGates > 0 ? 'warning' : 'success'} />
            </Box>
            {recentGates.length > 0 ? (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {recentGates.map((g) => (
                  <Box key={g.pm_projectgatereviewid} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: 1.5, borderRadius: 1.15, bgcolor: 'action.hover' }}>
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{g.pm_gatename ?? GATE_STAGE_LABELS[String(g.pm_gatestage)] ?? 'Gate Review'}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {g.pm_leadreviewer ? `Reviewer: ${g.pm_leadreviewer}` : GATE_STAGE_LABELS[String(g.pm_gatestage)] ?? `Stage ${g.pm_gatestage}`}
                        {g.pm_plannedreviewdate ? ` · ${new Date(g.pm_plannedreviewdate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}` : ''}
                      </Typography>
                    </Box>
                    <StatusTag
                      label={String(g.pm_reviewstatus) === '1' ? 'Scheduled' : OUTCOME_LABELS[String(g.pm_reviewoutcome)] ?? 'Complete'}
                      size="small"
                      color={String(g.pm_reviewstatus) === '1' ? 'info' : OUTCOME_COLORS[String(g.pm_reviewoutcome)] ?? 'success'}
                      variant="outlined"
                    />
                  </Box>
                ))}
              </Box>
            ) : (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 3 }}>
                No gate reviews yet.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>

      {/* ━━ Row 6: Bottom Summary Cards ━━ */}
      <Grid container spacing={2}>
        {/* Resource & Benefit */}
        <Grid size={{ xs: 12, sm: 6 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5, height: '100%' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5, display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <GroupIcon sx={{ fontSize: 18, color: 'primary.main' }} /> Resources & Benefits
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Box sx={{ flex: 1, textAlign: 'center', p: 1.5, bgcolor: 'action.hover', borderRadius: 1.5 }}>
                <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>{resources.length}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>Resources</Typography>
                {metrics.totalAllocatedHours > 0 && (
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontSize: fontSizes.xs }}>
                    {metrics.totalAllocatedHours}h allocated
                  </Typography>
                )}
              </Box>
              <Box sx={{ flex: 1, textAlign: 'center', p: 1.5, bgcolor: 'action.hover', borderRadius: 1.5 }}>
                <Typography variant="h5" sx={{ fontWeight: 700, color: 'warning.main' }}>{metrics.achievedBenefits}/{benefits.length}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>Benefits</Typography>
                {benefits.length > 0 && (
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontSize: fontSizes.xs }}>
                    {Math.round((metrics.achievedBenefits / benefits.length) * 100) || 0}% realized
                  </Typography>
                )}
              </Box>
            </Box>
          </Paper>
        </Grid>

        {/* Budget & Schedule */}
        <Grid size={{ xs: 12, sm: 6 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5, height: '100%' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5, display: 'flex', alignItems: 'center', gap: 0.75 }}>
              <AccountBalanceWalletIcon sx={{ fontSize: 18, color: 'success.main' }} /> Budget & Schedule
            </Typography>

            {/* Budget row */}
            {metrics.totalBudget > 0 && (
              <Box sx={{ mb: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                  <Typography variant="caption" sx={{ fontWeight: 600 }}>{currency(metrics.totalSpent)} / {currency(metrics.totalBudget)}</Typography>
                  <Typography variant="caption" color={budgetUtilPct > 90 ? 'error.main' : budgetUtilPct > 70 ? 'warning.main' : 'success.main'} sx={{ fontWeight: 700 }}>{budgetUtilPct}%</Typography>
                </Box>
                <LinearProgress
                  variant="determinate" value={budgetUtilPct}
                  sx={{ height: 6, borderRadius: 1.5, bgcolor: 'action.hover',
                    '& .MuiLinearProgress-bar': { borderRadius: 1.5, bgcolor: budgetUtilPct > 90 ? 'error.main' : budgetUtilPct > 70 ? 'warning.main' : 'success.main' },
                  }}
                />
              </Box>
            )}

            {/* Schedule row */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, pt: metrics.totalBudget > 0 ? 0 : 0 }}>
              <CalendarTodayIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
              <Box sx={{ flex: 1 }}>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>Schedule</Typography>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block' }}>
                  {project.pm_plannedstartdate ? new Date(project.pm_plannedstartdate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '—'}
                  {' — '}
                  {project.pm_plannedenddate ? new Date(project.pm_plannedenddate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                </Typography>
              </Box>
              <StatusChip status={project.pm_ragstatus} type="rag" size="small" />
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}

